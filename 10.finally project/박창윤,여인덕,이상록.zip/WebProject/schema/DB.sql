select * from customer2;
select *from market;
select*from 분식집;

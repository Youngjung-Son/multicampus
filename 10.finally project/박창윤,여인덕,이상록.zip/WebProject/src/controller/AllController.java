/* 학습내용
 * 1. command pattern 반영한 controller
 * 2. 여러개의 요청을 하나의 controller가 받아서 구분 후 
 *     각 요청별 로직 처리 
 * 3. 필요 로직
 * 		1. 요청 구분을 분기분(조건문장)
 * 		2. 각 로직을 처리하는 별도의 사용자 정의 메소드 구현
 * 		3. 요청별 사용자 정의 메소드 호출
 * 4. 실제 처리 로직 관점
 * 		1. 로그인 개발 단계
 * 			1. 로그인 요청인지 구분
 * 			2. id/pw값 획득
 * 			3. id/pw값의 존재 여부 체크
 * 				- null 여부, null이 아니면 DAO의 로그인 로직 처리 
 *  			  메소드 호출
 * 			4. 실행되는 경우의 수 
 * 				정상실행 
 * 					1. 존재한다 - name 값 반환
 * 						- 세션 생성
 * 						- 세션 이름값 저장
 * 						- SuccessView로 이름값 출력 위임(리다이렉트)
 * 							
 * 					2. 미존재한다 - null 값 반환
 * 				비정상 실행
 * 					예외 발생
 * 
 * 		2. 이름 변경
 *   
 */
package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CustomerDAO;
import model.domain.CustomerDTO;

@WebServlet("/cont")

public class AllController extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		// login or rename or logout or all(모든 검색 요청)........?
		String command = request.getParameter("command");

		if (command.equals("login")) {
			login(request, response);
		} else if (command.equals("sign up")) {
			signup(request, response);
		} else if (command.equals("update")) {
			update(request, response);
		} else if (command.equals("logout")) {
			logout(request, response);
		/*} else if(command.equals("find id")) {
			find_Id(request,response);
		} else if(command.equals("find pw")) {
			find_pw(request,response);*/
		} else if(command.equals("delete")) {
			delete(request,response);
		}else {
			response.sendRedirect("login.html");}
	}

	// 1.로그인 처리 메소드
	protected void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		if (id != null && pw != null) {
			try {
				String name = CustomerDAO.loginCheck(id, pw);
				if (name != null) {// 회원인 경우
					HttpSession session = request.getSession();
					session.setAttribute("name", name);
					response.sendRedirect("loginIndex.html"); // 여기다가 상권분석 링크 달아주기
				} else {// 미회원인 경우
					request.setAttribute("msg", "당신은 회원이 아니십니다");
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			response.sendRedirect("login.html");
		}
	} // 로그인 된 사라만 볼 수 있는 로직을 구성하려면?? How??  로그인이 되면, 링크를 준다
	
	// 2. 회원 가입 처리 메소드
	protected void signup(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String new_id = request.getParameter("id");
		String new_pw = request.getParameter("pw");	
		String new_name = request.getParameter("name");
		CustomerDTO newcustomer= new CustomerDTO(new_id, new_pw, new_name);
			try {
				
				boolean sign = CustomerDAO.signup(newcustomer);
				if (sign) {// 회원가입 내용을 제대로 작성한 경우
					HttpSession session = request.getSession();
					response.sendRedirect("login.html");
				} else {// 회원가입을 제대로 작성하지 못한 경우 
					request.setAttribute("msg", "회원가입에 실패했습니다.");
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			}catch(Exception e) {
				e.printStackTrace();
				response.sendRedirect("login.html");
			}
		} 
	
	//3. 회원 정보 수정 메소드 (Id & pw 수정하기)
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name=request.getParameter("name");
		// id랑 pw로 회원여부 판단을 위해서 받아와야함.
		if(id!=null && pw!=null) {
			try {
				boolean update=CustomerDAO.update(id, pw,name);
				if(update) {
					response.sendRedirect("정보 수정에 성공했습니다."); 
				}else {
					request.setAttribute("msg", "정보 수정에 실패했습니다."); 
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}else {
			response.sendRedirect("login.html"); 
		}												
	}

	//4. 로그아웃 처리 메소드
		protected void logout(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			HttpSession session = request.getSession();
			session.invalidate();
			session = null;
			response.sendRedirect("byView.jsp");
		}
	
	//5. 삭제 처리 메소드 	
	protected void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		// id랑 pw로 회원여부 판단을 위해서 받아와야함.
		if (id != null && pw != null) {
			try {
				boolean delete = CustomerDAO.delete(id, pw);
				if (delete) {
					response.sendRedirect("정보 삭제에 성공했습니다.");
				} else {
					request.setAttribute("msg", "정보 삭제에 실패했습니다.");
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			response.sendRedirect("login.html");
		}
	}
	
	
}
// http://ip:port/project명/login.html
// http://ip:port/project명
// http://ip:port/project명/cont
// http://ip:port/project명/byView.jsp
// http://ip:port/project명/msgView.jsp

/* 학습내용
 * 1. command pattern 반영한 controller
 * 2. 여러개의 요청을 하나의 controller가 받아서 구분 후 
 *     각 요청별 로직 처리 
 * 3. 필요 로직
 * 		1. 요청 구분을 분기분(조건문장)
 * 		2. 각 로직을 처리하는 별도의 사용자 정의 메소드 구현
 * 		3. 요청별 사용자 정의 메소드 호출
 * 4. 실제 처리 로직 관점
 * 		1. 로그인 개발 단계
 * 			1. 로그인 요청인지 구분
 * 			2. id/pw값 획득
 * 			3. id/pw값의 존재 여부 체크
 * 				- null 여부, null이 아니면 DAO의 로그인 로직 처리 
 *  			  메소드 호출
 * 			4. 실행되는 경우의 수 
 * 				정상실행 
 * 					1. 존재한다 - name 값 반환
 * 						- 세션 생성
 * 						- 세션 이름값 저장
 * 						- SuccessView로 이름값 출력 위임(리다이렉트)
 * 							
 * 					2. 미존재한다 - null 값 반환
 * 				비정상 실행
 * 					예외 발생
 * 
 * 		2. 이름 변경
 *   
 */
package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CustomerDAO;
import model.TradeanalysisDAO;
import model.domain.CustomerDTO;
import model.domain.TradeanalysisDTO;

@WebServlet("/cont2")

public class AllController2 extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String command = request.getParameter("command");
		//1. 업종별 검색
	
		if (command.equals("sector1")) {
			sector1(request, response);
		} else if (command.equals("sector2")) {
			sector2(request, response);
		} else if (command.equals("sector3")) {
			sector3(request, response);
		} else if (command.equals("sector4")) {
			sector4(request, response);
		} else if (command.equals("sector5")) {
			sector5(request, response);
		} else if (command.equals("sector6")) {
			sector6(request, response);
		} else if (command.equals("sector7")) {
			sector7(request, response);
		} else if (command.equals("sector8")) {
			sector8(request, response);
		} else if (command.equals("sector9")) {
			sector9(request, response);
		} else if (command.equals("sector10")) {
			sector10(request, response);
		} else if (command.equals("sector11")) {
			sector11(request, response);
		} else if (command.equals("sector12")) {
			sector12(request, response);
		} else if (command.equals("sector13")) {
			sector13(request, response);
		} else if (command.equals("sector14")) {
			sector14(request, response);
		} else if (command.equals("sector15")) {
			sector15(request, response);
		} else if (command.equals("sector16")) {
			sector16(request, response);
		} else if (command.equals("sector17")) {
			sector17(request, response);
		} else if (command.equals("sector18")) {
			sector18(request, response);
		} else if (command.equals("sector19")) {
			sector19(request, response);
		} else if (command.equals("sector20")) {
			sector20(request, response);
		} else if (command.equals("sector21")) {
			sector21(request, response);}
		else {
			response.sendRedirect("search.html");}// ajax 부분 내일 고려하기 
	}
	protected void sector1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<TradeanalysisDTO> find=null;
			try {
				    find=TradeanalysisDAO.sector1();
			
					HttpSession session = request.getSession();
					System.out.println("find: "+find);
					session.setAttribute("sector", find);
					response.sendRedirect("search1.jsp"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector2();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector3(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector3();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector4(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector4();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector5(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector5();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector6(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector6();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector7(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector7();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector8(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector8();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector9(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector9();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector10(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector10();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector11(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector11();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector12(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector12();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector13(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector13();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector14(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector14();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector15(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector15();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector16(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector16();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector17(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector17();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector18(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector18();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector19(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector19();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector20(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector20();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
	protected void sector21(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector21();
			
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				
			}catch(Exception e) {
				e.printStackTrace();
		}
	} 
/*	
	// 1.업종별 검색 처리 메소드
	protected void sector(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sector = request.getParameter("sector");
		if (sector!= null) {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.sector(sector);
				if (find != null) {
					HttpSession session = request.getSession();
					session.setAttribute("sector", find);
					response.sendRedirect("search1.html"); // 여기다가 상권분석 링크 달아주기
				} else {
					request.setAttribute("msg", "업종별 검색 실패");
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			response.sendRedirect("search.html");
		}
	} 
	
	// 2. 지역별 검색 처리 메소드
	protected void district(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String district = request.getParameter("district");
		if (district!= null) {
			try {
				 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.district(district);
				if (find != null) {// 회원인 경우
					HttpSession session = request.getSession();
					session.setAttribute("district", district);
					response.sendRedirect("searchSucc.jsp"); // 여기다가 상권분석 링크 달아주기
				} else {// 미회원인 경우
					request.setAttribute("msg", "지역별 검색 실패");
					request.getRequestDispatcher("msgView.jsp").forward(request, response);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			response.sendRedirect("search.html");
		}
	} 
	
	// 3. 지역별 검색 처리 메소드
		protected void search_district(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			String search_district = request.getParameter("search_district");
			if (search_district!= null) {
				try {
					 ArrayList<TradeanalysisDTO> find=TradeanalysisDAO.district(district);
					if (find != null) {// 회원인 경우
						HttpSession session = request.getSession();
						session.setAttribute("district", district);
						response.sendRedirect("searchSucc.jsp"); // 여기다가 상권분석 링크 달아주기
					} else {// 미회원인 경우
						request.setAttribute("msg", "지역별 검색 실패");
						request.getRequestDispatcher("msgView.jsp").forward(request, response);
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
			} else {
				response.sendRedirect("search.html");
			}
		} */

}

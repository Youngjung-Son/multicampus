package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.domain.CustomerDTO;
import util.DBUtil;

public class CustomerDAO {
	
	//1. 로그인 검증 
	public static String loginCheck(String id, String pw) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String name = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select name from"
					+ " customer2 where id=? and pw=?");
			
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rset = pstmt.executeQuery();

			if(rset.next()) {
				name = rset.getString(1);
			}
		}finally {
			DBUtil.close(con, pstmt, rset);
		}
		return name;
	}
	
	
	// 1. 회원가입하기
	public static boolean signup(CustomerDTO newCustomer) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("insert into customer2  values(?,?,?)");
			pstmt.setString(1, newCustomer.getId());
			pstmt.setString(2, newCustomer.getPw());
			pstmt.setString(3, newCustomer.getName());

			int result = pstmt.executeUpdate();
			if (result == 0) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtil.close(con, pstmt);
		}
		return true;
	}

	// 2. 회원 정보 수정하기(ID, 비밀번호, 이름 등 수정할 내용 지정해줄 것)
	public static boolean update(String newid, String newpw, String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("update customer2 set  id=? and pw=? where name=?"); // 컬럼명 지정해줄 것.
			pstmt.setString(1, newid);
			pstmt.setString(2, newpw);
			pstmt.setString(3, name);
			int result = pstmt.executeUpdate();
			if (result == 0) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtil.close(con, pstmt);
		}
		return true;
	}

	// 3. 회원 정보 삭제하기
	public static boolean delete(String id, String pw) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("delete from customer2 where id=? and pw=?");
			pstmt.setString(1, id);
			pstmt.setString(1, pw);

			int result = pstmt.executeUpdate();
			if (result == 0) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtil.close(con, pstmt);
		}
		return true;
	}

/*	// 4. ID 찾기
	public static String profileCheck_id(String name, String cellphone, String email) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String id = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con
					.prepareStatement("select id from customer where (name=? and cellphone=?) or (name=? and email=?)");
			pstmt.setString(1, name);
			pstmt.setString(2, cellphone);
			pstmt.setString(3, name);
			pstmt.setString(4, email);

			rset = pstmt.executeQuery();

			if (rset.next()) {
				id = rset.getString(1);
			}

		} finally {
			DBUtil.close(con, pstmt, rset);
		}

		return id;
	}

	// 5. 비밀번호 찾기
	public static String profileCheck_pw(String id, String name, String cellphone, String email) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String pw = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(
					"select pw from customer where (id=? and name=? and cellphone=?) or (id=? and name=? and email=?)");
			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, cellphone);
			pstmt.setString(4, name);
			pstmt.setString(5, name);
			pstmt.setString(6, email);

			rset = pstmt.executeQuery();

			if (rset.next()) {
				pw = rset.getString(1);
			}

		} finally {
			DBUtil.close(con, pstmt, rset);
		}

		return pw;
	}
*/
}

package model.domain;

public class TradeanalysisDTO {
	String main_district;
	String small_district;
	String sector;
	float survive01year;
	float survive12year;
	float survive23year;
	float survive35year;
	float survive5year;
	int avg_sale;
	float week_sale_ratio;
	float holiday_Sale_ratio;
	int week_sale;
	int holiday_sale;
	int store_number;
	public TradeanalysisDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TradeanalysisDTO(String main_district, String small_district, String sector, float survive01year,
			float survive12year, float survive23year, float survive35year, float survive5year, int avg_sale,
			float week_sale_ratio, float holiday_Sale_ratio, int week_sale, int holiday_sale, int store_number) {
		super();
		this.main_district = main_district;
		this.small_district = small_district;
		this.sector = sector;
		this.survive01year = survive01year;
		this.survive12year = survive12year;
		this.survive23year = survive23year;
		this.survive35year = survive35year;
		this.survive5year = survive5year;
		this.avg_sale = avg_sale;
		this.week_sale_ratio = week_sale_ratio;
		this.holiday_Sale_ratio = holiday_Sale_ratio;
		this.week_sale = week_sale;
		this.holiday_sale = holiday_sale;
		this.store_number = store_number;
	}
	public String getMain_district() {
		return main_district;
	}
	public void setMain_district(String main_district) {
		this.main_district = main_district;
	}
	public String getSmall_district() {
		return small_district;
	}
	public void setSmall_district(String small_district) {
		this.small_district = small_district;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public float getSurvive01year() {
		return survive01year;
	}
	public void setSurvive01year(float survive01year) {
		this.survive01year = survive01year;
	}
	public float getSurvive12year() {
		return survive12year;
	}
	public void setSurvive12year(float survive12year) {
		this.survive12year = survive12year;
	}
	public float getSurvive23year() {
		return survive23year;
	}
	public void setSurvive23year(float survive23year) {
		this.survive23year = survive23year;
	}
	public float getSurvive35year() {
		return survive35year;
	}
	public void setSurvive35year(float survive35year) {
		this.survive35year = survive35year;
	}
	public float getSurvive5year() {
		return survive5year;
	}
	public void setSurvive5year(float survive5year) {
		this.survive5year = survive5year;
	}
	public int getAvg_sale() {
		return avg_sale;
	}
	public void setAvg_sale(int avg_sale) {
		this.avg_sale = avg_sale;
	}
	public float getWeek_sale_ratio() {
		return week_sale_ratio;
	}
	public void setWeek_sale_ratio(float week_sale_ratio) {
		this.week_sale_ratio = week_sale_ratio;
	}
	public float getHoliday_Sale_ratio() {
		return holiday_Sale_ratio;
	}
	public void setHoliday_Sale_ratio(float holiday_Sale_ratio) {
		this.holiday_Sale_ratio = holiday_Sale_ratio;
	}
	public int getWeek_sale() {
		return week_sale;
	}
	public void setWeek_sale(int week_sale) {
		this.week_sale = week_sale;
	}
	public int getHoliday_sale() {
		return holiday_sale;
	}
	public void setHoliday_sale(int holiday_sale) {
		this.holiday_sale = holiday_sale;
	}
	public int getStore_number() {
		return store_number;
	}
	public void setStore_number(int store_number) {
		this.store_number = store_number;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TradeanalysisDTO [main_district=");
		builder.append(main_district);
		builder.append(", small_district=");
		builder.append(small_district);
		builder.append(", sector=");
		builder.append(sector);
		builder.append(", survive01year=");
		builder.append(survive01year);
		builder.append(", survive12year=");
		builder.append(survive12year);
		builder.append(", survive23year=");
		builder.append(survive23year);
		builder.append(", survive35year=");
		builder.append(survive35year);
		builder.append(", survive5year=");
		builder.append(survive5year);
		builder.append(", avg_sale=");
		builder.append(avg_sale);
		builder.append(", week_sale_ratio=");
		builder.append(week_sale_ratio);
		builder.append(", holiday_Sale_ratio=");
		builder.append(holiday_Sale_ratio);
		builder.append(", week_sale=");
		builder.append(week_sale);
		builder.append(", holiday_sale=");
		builder.append(holiday_sale);
		builder.append(", store_number=");
		builder.append(store_number);
		builder.append("]");
		return builder.toString();
	}
	
}

package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.TradeanalysisDTO;
import util.DBUtil;

public class TradeanalysisDAO {
	 public static ArrayList<TradeanalysisDTO> sector1() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='강남구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	        	 
	         }System.out.println("datas: "+datas);
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector2() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='강동구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector3() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='강북구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector4() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='강서구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector5() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='관악구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector6() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='광진구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector7() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='구로구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector8() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='금천구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector9() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='노원구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector10() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='도봉구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector11() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='동대문구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector12() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='동작구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector13() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='마포구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector14() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='서대문구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector15() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='서초구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector16() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='성동구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector17() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='성북구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector18() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='송파구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector19() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='양천구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector20() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='영등포구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
	 public static ArrayList<TradeanalysisDTO> sector21() throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district='용산구'");
	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	    	
		        }
		   return datas;
		
	
 /*  //1. 업종별 검색
   public static ArrayList<TradeanalysisDTO> sector(String sector) throws SQLException{
      Connection con = null;
      PreparedStatement pstmt1 = null;
      ResultSet rs =null;
      ArrayList<TradeanalysisDTO> datas = null;
      try {
         con=DBUtil.getConnection();
         pstmt1 = con.prepareStatement("select * from market where sector=?");
         pstmt1.setString(1, sector);

         rs = pstmt1.executeQuery();
         datas = new ArrayList<TradeanalysisDTO>();
         if(rs.next()) {
        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
         }
      } catch (SQLException e) {
         e.printStackTrace();
         throw e;
      }finally {
         DBUtil.close(con, pstmt1);
        }
   return datas;
   }

   
   //2.지역별 검색
   public static ArrayList<TradeanalysisDTO> district(String main_district) throws SQLException{
      Connection con = null;
      PreparedStatement pstmt1 = null;
      ResultSet rs =null;
      ArrayList<TradeanalysisDTO> datas = null;
      try {
         con=DBUtil.getConnection();
         pstmt1 = con.prepareStatement("select * from Tradeanalysis where main_district=?");
         pstmt1.setString(1, main_district);

         rs = pstmt1.executeQuery();
         datas = new ArrayList<TradeanalysisDTO>();
         if(rs.next()) {
        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
         }
      } catch (SQLException e) {
         e.printStackTrace();
         throw e;
      }finally {
         DBUtil.close(con, pstmt1);
        }
   return datas;
   }
   
   //3. 업종별 + 지역별 검색 
   //1). 분식집 
   public static ArrayList<TradeanalysisDTO> sector1(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 분식집 where main_district=강남구");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
 //2). 양식집 
   public static ArrayList<TradeanalysisDTO> sector2(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 양식집 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   }
 //3). 중국집 
   public static ArrayList<TradeanalysisDTO> sector3(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 중국집 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   //4). 일식집 
   public static ArrayList<TradeanalysisDTO> sector4(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 일식집 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   //5). 치킨집 
   public static ArrayList<TradeanalysisDTO> sector5(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 치킨집 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   //6). 커피 음료
   public static ArrayList<TradeanalysisDTO> sector6(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 커피음료 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   
   //7). 패스트푸드점
   public static ArrayList<TradeanalysisDTO> sector7(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 패스트푸드점 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   //8.한국음식점
   public static ArrayList<TradeanalysisDTO> sector8(String main_district) throws SQLException{
	      Connection con = null;
	      PreparedStatement pstmt1 = null;
	      ResultSet rs =null;
	      ArrayList<TradeanalysisDTO> datas = null;
	      try {
	         con=DBUtil.getConnection();
	         pstmt1 = con.prepareStatement("select * from 한식음식점 where main_district=?");
	         pstmt1.setString(1, main_district);

	         rs = pstmt1.executeQuery();
	         datas = new ArrayList<TradeanalysisDTO>();
	         if(rs.next()) {
	        	 datas.add(new TradeanalysisDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getFloat(5), rs.getFloat(6), 
	             		rs.getFloat(7), rs.getFloat(8), rs.getInt(9), rs.getFloat(10), rs.getFloat(11), rs.getInt(12), rs.getInt(13), rs.getInt(14)));
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         throw e;
	      }finally {
	         DBUtil.close(con, pstmt1);
	        }
	   return datas;
	   } 
   */
}
}
















